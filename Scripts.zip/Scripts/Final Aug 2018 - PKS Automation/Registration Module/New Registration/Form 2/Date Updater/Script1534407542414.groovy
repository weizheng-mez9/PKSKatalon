import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.util.Date as Date
import java.text.SimpleDateFormat as SimpleDateFormat

Date TodayDate = new Date()

//capture today's date
SimpleDateFormat CurrentDateNoFilter = new SimpleDateFormat()

//allow editing on date captured
CurrentDateNoFilter.applyPattern('dd')

//applying to show today's date
String CurrentDate = CurrentDateNoFilter.format(TodayDate)
CurrentDate = Integer.parseInt(CurrentDate)
GlobalVariable.CurrentDate = CurrentDate

//saving value of current date in a string
int CurrentDay = Integer.parseInt(CurrentDate)

//This is to allow adjusting to a day before
int aDayBefore = CurrentDay + 1

//adjusting to a day before
String DayBefore = aDayBefore.toString()
GlobalVariable.OneDayBefore = DayBefore

//saving value of a day before today
CurrentDateNoFilter.applyPattern('MM')

//applying to show today's month
int monthContainerMatcher = Integer.parseInt(CurrentDateNoFilter.format(TodayDate))

//container of month in the pop up is in index format, hence is 0 1 2 3 4 5 6 7 8 9 10 11
//to match the system month column value, we need a matcher
monthContainerMatcher = (monthContainerMatcher - 1)

//minus one will match the value
String CurrentMonth = monthContainerMatcher.toString()
GlobalVariable.CurrentMonth = CurrentMonth

//saving value of current month in a string
CurrentDateNoFilter.applyPattern('yyyy')

//applying to show today's year
String CurrentYear = CurrentDateNoFilter.format(TodayDate)
GlobalVariable.CurrentYear = CurrentYear

//saving value of current year in a string
int intCurrentYear = Integer.parseInt(CurrentDateNoFilter.format(TodayDate))

//allowing adjust year to n years ago
eighteenYrsAgo = (intCurrentYear - 18)

//adjusting year to 18 years ago
String eighteenYrsBeforeThisYr = eighteenYrsAgo.toString()
GlobalVariable.EighteenYrsBefore = eighteenYrsBeforeThisYr

//saving value of 18 years ago
fiftysevenYrsAgo = (intCurrentYear - 57)

//adjusting year to 57 years ago
String fiftysevenYrsBeforeThisYr = fiftysevenYrsAgo.toString()
GlobalVariable.FiftysevenYrsBefore = fiftysevenYrsBeforeThisYr

